**To delete a queue**

This example deletes the specified queue.

Command::

  aws sqs delete-queue --queue-url https://sqs.us-east-1.amazonaws.com/80398EXAMPLE/MyNewerQueue

Output::

  None.