**To remove a permission**

This example removes the permission with the specified label from the specified queue.

Command::

  aws sqs remove-permission --queue-url https://sqs.us-east-1.amazonaws.com/80398EXAMPLE/MyQueue --label SendMessagesFromMyQueue

Output::

  None.